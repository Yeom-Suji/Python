import sys
sys.path.append('C:/Users/LG/Desktop/online_mall')


from datetime import datetime
from models.product import Product
from models.transaction import Transaction
from utilities.database import Database
from models.comment import Comment
from customer_system.models.promotion import Promotion
from utilities.order_management import OrderManagement
from customer_system.models.customer import Customer
from customer_system.utilities.cart import Cart



def main():
    db = Database()

    # Add products
    product1 = Product(1, "Wedding Dress", "High-quality white dress", 1500.0, 10)
    db.add_product(product1)

    product2 = Product(2, "New Jeans", "Jeans", 200.0, 15)
    db.add_product(product2)

    # Add promotions
    promotion1 = Promotion(1, "Summer Sale", "10% off on all items", 0.10)
    db.add_promotion(promotion1)

    promotion2 = Promotion(2, "Birthday Discount", "50% off on your birthday", 0.50)
    db.add_promotion(promotion2)

    # Add customers
    from customer_system.models.customer import Customer
    customer1 = Customer(1, "Suji", "Suji@example.com", "password", "123 Main St", "555-1234", 1990)
    db.add_customer(customer1)

    customer2 = Customer(2, "Jane", "jane@example.com", "password123", "456 Elm St", "555-5678", 1985)
    db.add_customer(customer2)

    # Perform transaction
    from customer_system.utilities.cart import Cart
    cart = Cart()
    cart.add_item(product1, 1)
    cart.add_item(product2, 2)
    total_amount = cart.total_amount()

    transaction = Transaction(1, customer1.customer_id, cart.items, total_amount, 'pending', datetime.now())
    db.add_transaction(transaction)

    # Manage orders
    OrderManagement.update_order_status(transaction, 'shipping')
    if not OrderManagement.cancel_order(transaction):
        print("Cannot cancel order as it is not in pending status.")

    # Add comments
    OrderManagement.add_comment(transaction, customer1.customer_id, "Thank you for the fast shipping!")
    db.add_comment(Comment(customer1.customer_id, "Great service!"))

    # Print database state
    print(f"Customers: {db.list_customers()}")
    print(f"Products: {db.list_products()}")
    print(f"Transactions: {db.list_transactions()}")
    print(f"Comments: {db.list_comments()}")
    print(f"Promotions: {db.list_promotions()}")

if __name__ == "__main__":
    main()
