class Comment:
    """
    A class representing a comment made by a customer.

    Attributes:
        customer_id (int): The identifier of the customer who made the comment.
        text (str): The text content of the comment.

    Methods:
        get_info():
            Returns a dictionary containing the comment information.
    """

    def __init__(self, customer_id: int, text: str):
        """
        Initialize a new Comment object.

        Args:
            customer_id (int): The identifier of the customer who made the comment.
            text (str): The text content of the comment.
        """
        self.customer_id = customer_id
        self.text = text

    def get_info(self) -> dict:
        """
        Retrieve the information of the comment as a dictionary.

        Returns:
            dict: A dictionary containing the comment information.
                Keys:
                - 'customer_id' (int): The identifier of the customer who made the comment.
                - 'text' (str): The text content of the comment.
        """
        return {
            "customer_id": self.customer_id,
            "text": self.text
        }
