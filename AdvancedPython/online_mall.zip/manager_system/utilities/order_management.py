import sys
sys.path.append('C:/Users/LG/Desktop/online_mall')

from manager_system.models.comment import Comment
from manager_system.utilities.database import Database

class OrderManagement:
    @staticmethod
    def update_order_status(transaction, status):
        transaction.status = status

    @staticmethod
    def cancel_order(transaction):
        if transaction.status == 'pending':
            transaction.status = 'canceled'
            return True
        return False

    @staticmethod
    def add_comment(transaction, customer_id, text):
        comment = Comment(customer_id, text)
        transaction.add_comment(comment)
