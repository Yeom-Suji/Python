class Database:
    """
    A class representing a database for managing various entities related to an online mall.

    Attributes:
        products (dict): A dictionary to store Product objects, keyed by product_id.
        transactions (dict): A dictionary to store Transaction objects, keyed by transaction_id.
        comments (list): A list to store Comment objects, preserving the order of comments.
        promotions (dict): A dictionary to store Promotion objects, keyed by promotion_id.
        customers (dict): A dictionary to store Customer objects, keyed by customer_id.

    Methods:
        add_product(product):
            Adds a Product object to the database.

        list_products():
            Returns a list of all Product objects stored in the database.

        add_transaction(transaction):
            Adds a Transaction object to the database.

        list_transactions():
            Returns a list of all Transaction objects stored in the database.

        add_comment(comment):
            Adds a Comment object to the database.

        list_comments():
            Returns a list of all Comment objects stored in the database.

        add_promotion(promotion):
            Adds a Promotion object to the database.

        list_promotions():
            Returns a list of all Promotion objects stored in the database.

        add_customer(customer):
            Adds a Customer object to the database.

        list_customers():
            Returns a list of all Customer objects stored in the database.

        get_customer_by_id(customer_id):
            Retrieves a Customer object from the database by customer_id.

        get_product_by_id(product_id):
            Retrieves a Product object from the database by product_id.

        get_transaction_by_id(transaction_id):
            Retrieves a Transaction object from the database by transaction_id.

        get_promotion_by_id(promotion_id):
            Retrieves a Promotion object from the database by promotion_id.
    """

    def __init__(self):
        """
        Initialize an empty Database object with empty collections for each entity type.
        """
        self.products = {}      # Product storage
        self.transactions = {}  # Transaction storage
        self.comments = []      # Comment storage (list to keep order)
        self.promotions = {}    # Promotion storage
        self.customers = {}     # Customer storage

    def add_product(self, product):
        """
        Add a Product object to the database.

        Args:
            product (Product): The Product object to be added.
        """
        self.products[product.product_id] = product

    def list_products(self):
        """
        Retrieve a list of all Product objects stored in the database.

        Returns:
            list: A list of all Product objects stored in the database.
        """
        return list(self.products.values())

    def add_transaction(self, transaction):
        """
        Add a Transaction object to the database.

        Args:
            transaction (Transaction): The Transaction object to be added.
        """
        self.transactions[transaction.transaction_id] = transaction

    def list_transactions(self):
        """
        Retrieve a list of all Transaction objects stored in the database.

        Returns:
            list: A list of all Transaction objects stored in the database.
        """
        return list(self.transactions.values())

    def add_comment(self, comment):
        """
        Add a Comment object to the database.

        Args:
            comment (Comment): The Comment object to be added.
        """
        self.comments.append(comment)

    def list_comments(self):
        """
        Retrieve a list of all Comment objects stored in the database.

        Returns:
            list: A list of all Comment objects stored in the database.
        """
        return self.comments

    def add_promotion(self, promotion):
        """
        Add a Promotion object to the database.

        Args:
            promotion (Promotion): The Promotion object to be added.
        """
        self.promotions[promotion.promotion_id] = promotion

    def list_promotions(self):
        """
        Retrieve a list of all Promotion objects stored in the database.

        Returns:
            list: A list of all Promotion objects stored in the database.
        """
        return list(self.promotions.values())

    def add_customer(self, customer):
        """
        Add a Customer object to the database.

        Args:
            customer (Customer): The Customer object to be added.
        """
        self.customers[customer.customer_id] = customer

    def list_customers(self):
        """
        Retrieve a list of all Customer objects stored in the database.

        Returns:
            list: A list of all Customer objects stored in the database.
        """
        return list(self.customers.values())

    def get_customer_by_id(self, customer_id):
        """
        Retrieve a Customer object from the database by customer_id.

        Args:
            customer_id (int): The identifier of the customer to retrieve.

        Returns:
            Customer or None: The Customer object if found, None if not found.
        """
        return self.customers.get(customer_id)

    def get_product_by_id(self, product_id):
        """
        Retrieve a Product object from the database by product_id.

        Args:
            product_id (int): The identifier of the product to retrieve.

        Returns:
            Product or None: The Product object if found, None if not found.
        """
        return self.products.get(product_id)

    def get_transaction_by_id(self, transaction_id):
        """
        Retrieve a Transaction object from the database by transaction_id.

        Args:
            transaction_id (int): The identifier of the transaction to retrieve.

        Returns:
            Transaction or None: The Transaction object if found, None if not found.
        """
        return self.transactions.get(transaction_id)

    def get_promotion_by_id(self, promotion_id):
        """
        Retrieve a Promotion object from the database by promotion_id.

        Args:
            promotion_id (int): The identifier of the promotion to retrieve.

        Returns:
            Promotion or None: The Promotion object if found, None if not found.
        """
        return self.promotions.get(promotion_id)
