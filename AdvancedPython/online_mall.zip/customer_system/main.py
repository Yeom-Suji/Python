import sys
sys.path.append('C:/Users/LG/Desktop/online_mall')

from datetime import datetime
from models.customer import Customer
from models.product import Product
from models.transaction import Transaction
from models.promotion import Promotion
from utilities.database import Database
from utilities.cart import Cart
from utilities.auth import Auth


def main():
    db = Database()

    # Sample products
    product1 = Product(1, "Wedding Dress", "High-quality white dress", 1500.0, 10)
    product2 = Product(2, "New Jeans", "Jeans", 200.0, 15)
    db.add_product(product1)
    db.add_product(product2)

    # Sample promotions
    promotion1 = Promotion(1, "Birthday Discount", "50% off on your birthday", 0.50)
    db.add_promotion(promotion1)

    # Sample customers
    customer1 = Customer(1, "Suji", "suji@example.com", "password", "123 Main St", "555-1234", 1990)
    customer2 = Customer(2, "Jane", "jane@example.com", "password123", "456 Elm St", "555-5678", 1985)
    db.add_customer(customer1)
    db.add_customer(customer2)

    # Authentication (Login and Logout)
    auth = Auth(db)
    login_success = auth.login("suji@example.com", "password")
    if not login_success:
        print("Login failed")
        return
    auth.logout()

    # My Page: Viewing and managing customer info
    print("\n--- My Page ---")
    login_success = auth.login("suji@example.com", "password")
    if not login_success:
        print("Login failed")
        return
    
    current_customer = auth.current_user
    print(f"Customer Info: {current_customer.get_info()}")

    # Change info
    current_customer.update_info(name="Suji", address="789 Oak St")
    print(f"Updated Info: {current_customer.get_info()}")

    # Register new info (simply a re-login for now)
    auth.logout()
    auth.login("suji@example.com", "password")

    # My Orders
    print("\n--- My Orders ---")
    cart = Cart()
    cart.add_item(product1, 1)
    cart.add_item(product2, 2)
    total_amount = cart.total_amount()
    transaction = Transaction(1, current_customer.customer_id, cart.items, total_amount, 'pending', datetime.now())
    db.add_transaction(transaction)
    print(f"My Orders: {db.get_customer_transactions(current_customer.customer_id)}")

    # My Money/Points
    print(f"My Points: {current_customer.points}")

    # My Cart
    print("\n--- My Cart ---")
    print("Initial Cart View:", cart.view_cart())
    cart.remove_item(product2)
    print(f"Cart after removing New Jeans: {cart.view_cart()}")

    # Checkout
    print(f"Total Amount after checkout: {cart.total_amount()}")

    # Delete Account
    print("\n--- Deleting Account ---")
    db.delete_customer(current_customer.customer_id)
    print(f"Remaining Customers: {db.list_customers()}")

if __name__ == "__main__":
    main()
