class Product:
    """
    A class representing a product.

    Attributes:
        product_id (int): The unique identifier for the product.
        name (str): The name of the product.
        description (str): A brief description of the product.
        price (float): The price of the product.
        stock (int): The available quantity of the product.

    Methods:
        update_info(name=None, description=None, price=None, stock=None):
            Update the information of the product with new values.

        get_info():
            Retrieve information about the product as a dictionary.
    """

    def __init__(self, product_id, name, description, price, stock):
        """
        Initialize a Product object with the provided attributes.

        Args:
            product_id (int): The unique identifier for the product.
            name (str): The name of the product.
            description (str): A brief description of the product.
            price (float): The price of the product.
            stock (int): The available quantity of the product.
        """
        self.product_id = product_id
        self.name = name
        self.description = description
        self.price = price
        self.stock = stock

    def update_info(self, name=None, description=None, price=None, stock=None):
        """
        Update the information of the product with new values.

        Args:
            name (str, optional): The new name of the product.
            description (str, optional): The new description of the product.
            price (float, optional): The new price of the product.
            stock (int, optional): The new stock quantity of the product.
        """
        if name:
            self.name = name
        if description:
            self.description = description
        if price:
            self.price = price
        if stock:
            self.stock = stock

    def get_info(self):
        """
        Retrieve information about the product as a dictionary.

        Returns:
            dict: A dictionary containing 'product_id', 'name', 'description', 'price', and 'stock'.
        """
        return {
            "product_id": self.product_id,
            "name": self.name,
            "description": self.description,
            "price": self.price,
            "stock": self.stock
        }
