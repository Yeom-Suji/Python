class Transaction:
    """
    A class representing a transaction made by a customer.

    Attributes:
        transaction_id (int): The unique identifier for the transaction.
        customer_id (int): The identifier of the customer making the transaction.
        items (list): A list of items involved in the transaction.
        total_amount (float): The total amount paid in the transaction.
        status (str): The current status of the transaction.
        timestamp (str): The timestamp indicating when the transaction occurred.
        comments (list): A list to store comments associated with the transaction.

    Methods:
        add_comment(comment):
            Adds a comment to the transaction.

        get_info():
            Returns a dictionary containing the transaction information, including comments.
    """

    def __init__(self, transaction_id: int, customer_id: int, items: list, total_amount: float, status: str, timestamp: str):
        """
        Initialize a new Transaction object.

        Args:
            transaction_id (int): The unique identifier for the transaction.
            customer_id (int): The identifier of the customer making the transaction.
            items (list): A list of items involved in the transaction.
            total_amount (float): The total amount paid in the transaction.
            status (str): The current status of the transaction.
            timestamp (str): The timestamp indicating when the transaction occurred.
        """
        self.transaction_id = transaction_id
        self.customer_id = customer_id
        self.items = items
        self.total_amount = total_amount
        self.status = status
        self.timestamp = timestamp
        self.comments = []

    def add_comment(self, comment: str) -> None:
        """
        Add a comment to the transaction.

        Args:
            comment (str): The comment to be added.
        """
        self.comments.append(comment)

    def get_info(self) -> dict:
        """
        Retrieve the information of the transaction as a dictionary.

        Returns:
            dict: A dictionary containing the transaction information.
                Keys:
                - 'transaction_id' (int): The unique identifier for the transaction.
                - 'customer_id' (int): The identifier of the customer making the transaction.
                - 'items' (list): A list of items involved in the transaction.
                - 'total_amount' (float): The total amount paid in the transaction.
                - 'status' (str): The current status of the transaction.
                - 'timestamp' (str): The timestamp indicating when the transaction occurred.
                - 'comments' (list): A list of dictionaries containing each comment.
        """
        return {
            "transaction_id": self.transaction_id,
            "customer_id": self.customer_id,
            "items": self.items,
            "total_amount": self.total_amount,
            "status": self.status,
            "timestamp": self.timestamp,
            "comments": [comment for comment in self.comments]
        }
