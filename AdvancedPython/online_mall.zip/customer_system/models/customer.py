class Customer:
    """
    A class representing a customer.

    Attributes:
        TIER_POINTS (dict): A dictionary mapping tier names to their corresponding points multiplier.
        customer_id (int): The unique identifier for the customer.
        name (str): The name of the customer.
        email (str): The email address of the customer.
        password (str): The password of the customer.
        address (str): The address of the customer.
        phone (str): The phone number of the customer.
        birth_year (int): The birth year of the customer.
        points (float): The accumulated points of the customer.
        tier (str): The tier of the customer (e.g., Bronze, Silver, Gold, Diamond).
        login_logs (list): A list of login log entries for the customer.

    Methods:
        get_info():
            Retrieve information about the customer as a dictionary.

        update_info(name=None, address=None, phone=None):
            Update the information of the customer with new values.

        accumulate_points(amount):
            Accumulate points for the customer based on a transaction amount.

        change_tier(new_tier):
            Change the tier of the customer.

        add_login_log(log):
            Add a login log entry for the customer.

        list_login_logs():
            Retrieve a list of login log entries for the customer.
    """

    TIER_POINTS = {
        "Bronze": 0,
        "Silver": 0.05,
        "Gold": 0.10,
        "Diamond": 0.15
    }

    def __init__(self, customer_id, name, email, password, address, phone, birth_year):
        """
        Initialize a Customer object with the provided attributes.

        Args:
            customer_id (int): The unique identifier for the customer.
            name (str): The name of the customer.
            email (str): The email address of the customer.
            password (str): The password of the customer.
            address (str): The address of the customer.
            phone (str): The phone number of the customer.
            birth_year (int): The birth year of the customer.
        """
        self.customer_id = customer_id
        self.name = name
        self.email = email
        self.password = password
        self.address = address
        self.phone = phone
        self.birth_year = birth_year
        self.points = 0
        self.tier = "Bronze"  # Default tier
        self.login_logs = []

    def get_info(self):
        """
        Retrieve information about the customer as a dictionary.

        Returns:
            dict: A dictionary containing 'customer_id', 'name', 'email', 'address',
                  'phone', 'birth_year', 'points', and 'tier'.
        """
        return {
            "customer_id": self.customer_id,
            "name": self.name,
            "email": self.email,
            "address": self.address,
            "phone": self.phone,
            "birth_year": self.birth_year,
            "points": self.points,
            "tier": self.tier
        }

    def update_info(self, name=None, address=None, phone=None):
        """
        Update the information of the customer with new values.

        Args:
            name (str, optional): The new name of the customer.
            address (str, optional): The new address of the customer.
            phone (str, optional): The new phone number of the customer.
        """
        if name:
            self.name = name
        if address:
            self.address = address
        if phone:
            self.phone = phone

    def accumulate_points(self, amount):
        """
        Accumulate points for the customer based on a transaction amount.

        Args:
            amount (float): The amount to accumulate points for.
        """
        self.points += amount * self.TIER_POINTS[self.tier]

    def change_tier(self, new_tier):
        """
        Change the tier of the customer.

        Args:
            new_tier (str): The new tier name to set for the customer.
        """
        if new_tier in self.TIER_POINTS:
            self.tier = new_tier

    def add_login_log(self, log):
        """
        Add a login log entry for the customer.

        Args:
            log (str): The login log entry to add.
        """
        self.login_logs.append(log)

    def list_login_logs(self):
        """
        Retrieve a list of login log entries for the customer.

        Returns:
            list: A list of login log entries.
        """
        return self.login_logs
