class Promotion:
    """
    A class representing a promotion.

    Attributes:
        promotion_id (int): The unique identifier for the promotion.
        title (str): The title or name of the promotion.
        description (str): A brief description or details about the promotion.
        discount_rate (float): The discount rate applied by the promotion (in percentage).

    Methods:
        get_info():
            Returns a dictionary containing information about the promotion.
    """

    def __init__(self, promotion_id, title, description, discount_rate):
        """
        Initialize a Promotion object with the provided attributes.

        Args:
            promotion_id (int): The unique identifier for the promotion.
            title (str): The title or name of the promotion.
            description (str): A brief description or details about the promotion.
            discount_rate (float): The discount rate applied by the promotion (in percentage).
        """
        self.promotion_id = promotion_id
        self.title = title
        self.description = description
        self.discount_rate = discount_rate

    def get_info(self):
        """
        Get information about the promotion as a dictionary.

        Returns:
            dict: A dictionary containing 'promotion_id', 'title', 'description', and 'discount_rate'.
        """
        return {
            "promotion_id": self.promotion_id,
            "title": self.title,
            "description": self.description,
            "discount_rate": self.discount_rate
        }
