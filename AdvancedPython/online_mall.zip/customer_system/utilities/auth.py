from datetime import datetime

from datetime import datetime

class Auth:
    """
    A class for handling user authentication.

    Attributes:
        db (Database): The database instance where customer data is stored.
        current_user (Customer or None): The currently authenticated customer.

    Methods:
        login(email, password):
            Authenticate a customer based on email and password.

        logout():
            Log out the currently authenticated customer.
    """

    def __init__(self, db):
        """
        Initialize the Auth object with a database instance.

        Args:
            db (Database): The database instance to use for customer authentication.
        """
        self.db = db
        self.current_user = None

    def login(self, email, password):
        """
        Authenticate a customer based on email and password.

        If authentication is successful, set the current_user attribute and log the login event.
        If authentication fails, print an error message.

        Args:
            email (str): The email of the customer.
            password (str): The password of the customer.

        Returns:
            bool: True if login is successful, False otherwise.
        """
        for customer in self.db.list_customers():
            if customer.email == email and customer.password == password:
                self.current_user = customer
                print(f"Logged in as {customer.name}")
                customer.add_login_log(f"Logged in at {datetime.now()}")
                return True

        print("Login failed")
        return False

    def logout(self):
        """
        Log out the currently authenticated customer.

        If a customer is logged in, log the logout event and set current_user to None.
        If no customer is logged in, print a message indicating so.
        """
        if self.current_user:
            print(f"Logged out from {self.current_user.name}")
            self.current_user.add_login_log(f"Logged out at {datetime.now()}")
            self.current_user = None
        else:
            print("No user is currently logged in")
