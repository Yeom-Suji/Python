import sys
sys.path.append('C:/Users/LG/Desktop/online_mall')

from customer_system.models.product import Product

class Cart:
    """
    A class representing a shopping cart.

    Attributes:
        items (dict): A dictionary to store items in the cart, keyed by product_id.

    Methods:
        add_item(product, quantity):
            Adds a specified quantity of a product to the cart.

        remove_item(product):
            Removes a product from the cart.

        view_cart():
            Returns a list of dictionaries representing the current contents of the cart.

        total_amount():
            Calculates and returns the total monetary value of all items in the cart.
    """

    def __init__(self):
        """
        Initialize an empty Cart object with an empty items dictionary.
        """
        self.items = {}

    def add_item(self, product, quantity):
        """
        Add a specified quantity of a product to the cart.

        If the product is already in the cart, increase its quantity by the specified amount.
        If the product is not in the cart, add it with the specified quantity.

        Args:
            product (Product): The Product object to add to the cart.
            quantity (int): The quantity of the product to add.
        """
        if product.product_id in self.items:
            self.items[product.product_id]['quantity'] += quantity
        else:
            self.items[product.product_id] = {'product': product, 'quantity': quantity}

    def remove_item(self, product):
        """
        Remove a product from the cart.

        Args:
            product (Product): The Product object to remove from the cart.
        """
        if product.product_id in self.items:
            del self.items[product.product_id]

    def view_cart(self):
        """
        View the current contents of the cart.

        Returns:
            list: A list of dictionaries representing each item in the cart.
                Each dictionary contains 'product' information (from get_info()) and 'quantity'.
        """
        return [{**item['product'].get_info(), 'quantity': item['quantity']} for item in self.items.values()]

    def total_amount(self):
        """
        Calculate the total monetary value of all items in the cart.

        Returns:
            float: The total monetary value of all items in the cart.
        """
        return sum(item['product'].price * item['quantity'] for item in self.items.values())
