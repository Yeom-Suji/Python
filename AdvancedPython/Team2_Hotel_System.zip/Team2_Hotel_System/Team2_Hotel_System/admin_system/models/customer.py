from datetime import datetime

class Customer:
    def __init__(self, customer_id, name, contact_info, birth_year):
        self.customer_id = customer_id
        self.name = name
        self.contact_info = contact_info
        self.birth_year = birth_year
        self.membership_tier = 'bronze'
        self.points = 0
        self.stay_count = 0  # 고객의 올해 숙박 횟수를 저장
        self.reservations = []
        self.comments = []

    def add_comment(self, comment):
        self.comments.append(comment)

    def fetch_comments(self):
        return self.comments

    def add_reservation(self, reservation):
        self.reservations.append(reservation)
        
    def update_stay_count(self):
        current_year = datetime.now().year
        self.stay_count = sum(1 for res in self.reservations if res.start_date.year == current_year)
    
    def update_membership_tier(self):
        if self.points > 500000:
            self.membership_tier = 'diamond'
        elif self.points > 200000:
            self.membership_tier = 'platinum'
        elif self.points > 50000:
            self.membership_tier = 'gold'
        elif self.points > 10000:
            self.membership_tier = 'silver'
        else:
            self.membership_tier = 'bronze'

    def __str__(self):
        comments_str = ', '.join(self.comments)
        return (f"Customer ID: {self.customer_id}, Name: {self.name}, "
                f"Contact Info: {self.contact_info}, Comments: [{comments_str}]")
