from datetime import datetime

class Invoice:
    def __init__(self, customer, room, start_date, end_date, total_amount, notifications_summary="", promotion_details=[]):
        self.customer_name = customer.name
        self.customer_id = customer.customer_id
        self.start_date = start_date
        self.end_date = end_date
        self.room_type = room.style
        self.room_number = room.room_number
        self.total_amount = total_amount
        self.notifications_summary = notifications_summary
        self.promotion_details = promotion_details
        self.date_of_issue = datetime.now()

    def __str__(self):
        invoice_details = (f"Invoice for {self.customer_name} (ID: {self.customer_id})\n"
                           f"Room: {self.room_type} ({self.room_number})\n"
                           f"Stay: {self.start_date} to {self.end_date}\n"
                           f"Total Amount: {self.total_amount}\n"
                           f"Issued on: {self.date_of_issue}\n")
        if self.notifications_summary:
            invoice_details += f"Additional Charges:\n{self.notifications_summary}\n"
        if self.promotion_details:
            invoice_details += "Applied Promotions:\n" + "\n".join(self.promotion_details) + "\n"
        return invoice_details
