from datetime import datetime, timedelta, time
from abc import ABC, abstractmethod


class Search(ABC):
    @abstractmethod
    def search(self, style, start_date, duration):
        pass

class Room(Search):
    
    EARLY_CHECK_IN_TIME = time(13, 0)  # 13:00
    CHECK_IN_TIME = time(15, 0)  # 15:00
    CHECK_OUT_TIME = time(12, 0)  # 12:00
    LATE_CHECK_OUT_TIME = time(16, 0)  # 16:00
    
    ROOM_CAPACITIES = {
        'standard': 2,
        'executive': 3,
        'deluxe': 4,
        'suite': 6,
        'family_suite': 6
    }
    
    def __init__(self, room_number, room_style, status, price):
        self.room_number = room_number
        self.style = room_style # standard, executive, deluxe, suite, family_suite
        self.status = status # ready, reserved, occupied, house_keeping
        self.booking_price = price # differenciated by room_style
        self.max_capacity = self.ROOM_CAPACITIES.get(room_style, 2)

        self.reservations = []

    def is_room_available(self, start_date, duration):
        end_date = start_date + timedelta(days=duration) 
        for reservation in self.reservations: # 객실의 예약을 확인
            res_start = reservation.start_date 
            res_end = res_start + timedelta(days=reservation.duration_in_days)
            if (start_date < res_end and end_date > res_start):  
                return False
        return True

    def check_in(self, reservation, checkin_time=None):
        if checkin_time is None:
            checkin_time = datetime.now()
        if checkin_time.time() < Room.EARLY_CHECK_IN_TIME: # 현재시각이 13시 이전이면
            print("Check-in not allowed before 13:00.") 
            return False # 체크인 불가
        else:
            if Room.EARLY_CHECK_IN_TIME < checkin_time.time() < Room.CHECK_IN_TIME: # if checkin_time is between 13~15
                reservation.status = 'early_checked_in' # early checked in
            else: # if checkin_time is after 15
                reservation.status = 'checked_in'# checked in
            reservation.checkin = checkin_time
            self.status = 'occupied'
            self.reservations.append(reservation)
            return True

    def check_out(self, reservation, checkout_time=None):
        if checkout_time is None:
            checkout_time = datetime.now()
        if checkout_time.time() > Room.LATE_CHECK_OUT_TIME: # if checkout_time is after 16
            print("Check-out not allowed after 16:00.")
            return False
        else:
            if Room.CHECK_OUT_TIME < checkout_time.time() < Room.LATE_CHECK_OUT_TIME: # if checkout_time is between 12~16
                reservation.status = 'late_checked_out'  # late checked out
            else: # if checkout_time is before 12
                reservation.status = 'checked_out' # checked out
            reservation.checkout = checkout_time
            self.status = 'house_keeping'
            self.reservations.remove(reservation)
            return True 
    
    def finish_house_keeping(self):
        if self.status == 'house_keeping':
            self.status = 'ready'
            return True
        return False

    def search(self, style, start_date, duration):
        return self.style == style and self.is_room_available(start_date, duration)
    
    def __str__(self):
        reservations_str = ', '.join(str(res) for res in self.reservations)
        return (f"Room Number: {self.room_number}, Style: {self.style}, Status: {self.status}, "
                f"Price: {self.booking_price}, Reservations: [{reservations_str}]")
