from datetime import timedelta
from utilities.promotion import MembershipDiscount, StayCountDiscount, AgeDiscount
from .invoice import Invoice

class Reservation:
    def __init__(self, reservation_number, start_date, duration_in_days, room_style, booking_status, customer):
        self.reservation_number = reservation_number
        self.start_date = start_date
        self.duration_in_days = duration_in_days
        self.room_style = room_style
        self.status = booking_status # requested, confirmed, checked_in, checked_out
        self.checkin = None
        self.checkout = None
        self.customer = customer
        self.total_amount = 0
        self.promotion_details = []  # 프로모션 적용 세부사항
        
        self.room = None
        self.checkin_invoice = None
        self.checkout_invoice = None
        self.notifications = []

    def calculate_total_amount(self):
        self.total_amount = self.room.booking_price * self.duration_in_days
        self.promotion_details.clear()
        
        # Apply promotions
        promotions = [MembershipDiscount(), StayCountDiscount(), AgeDiscount()]
        for promotion in promotions:
            promotion.apply(self)
    
    def fetch_details(self):
        details = {
            "reservation_number": self.reservation_number,
            "start_date": self.start_date,
            "duration_in_days": self.duration_in_days,
            "status": self.status,
            "checkin": self.checkin,
            "checkout": self.checkout,
            "customer": {
                "customer_id": self.customer.customer_id,
                "name": self.customer.name,
                "contact_info": self.customer.contact_info,
            },
            "room": self.room,
            "checkin_invoice": self.checkin_invoice,
            "checkout_invoice": self.checkout_invoice,
            "notifications": self.notifications,
            "promotion_details": self.promotion_details
        }
        return details

    def update_status(self, new_status):
        self.status = new_status
        
    def assign_room(self, db, room_number):
        room = db.find_room_by_number(room_number)
        if room and room.is_room_available(self.start_date, self.duration_in_days):
            self.room = room
            self.update_status('confirmed')
            room.status = 'reserved'
            room.reservations.append(self)
            return True
        return False
    
    def create_checkin_invoice(self):
        self.calculate_total_amount()
        self.checkin_invoice = Invoice(
            customer=self.customer,
            room=self.room,
            start_date=self.start_date,
            end_date=self.start_date + timedelta(days=self.duration_in_days),
            total_amount=self.total_amount,
            promotion_details=self.promotion_details
        )

    def create_checkout_invoice(self):
        self.calculate_total_amount()
        total_amount = self.total_amount
        notifications_summary = "\n".join([f"{notification['description']}: {notification['cost']}" for notification in self.notifications])
        total_cost = sum(notification['cost'] for notification in self.notifications)
        total_amount += total_cost
        
        # Add points
        points_earned = int(self.total_amount * 0.01)
        self.customer.points += points_earned
        self.customer.update_membership_tier()

        self.checkout_invoice = Invoice(
            customer=self.customer,
            room=self.room,
            start_date=self.start_date,
            end_date=self.start_date + timedelta(days=self.duration_in_days),
            total_amount=total_amount,
            notifications_summary=notifications_summary,
            promotion_details=self.promotion_details
        )
        
    def add_notification(self, description, cost):
        self.notifications.append({"description": description, "cost": cost})
        
    def __str__(self):
        return (f"Reservation Number: {self.reservation_number}, Start Date: {self.start_date}, "
                f"Duration: {self.duration_in_days} days, Style: {self.room_style}, Status: {self.status}, "
                f"Customer: {self.customer.name} ({self.customer.contact_info})")
