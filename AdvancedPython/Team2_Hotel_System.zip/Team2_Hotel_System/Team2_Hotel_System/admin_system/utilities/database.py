class Database:
    def __init__(self):
        self.rooms = {}
        self.reservations = []
        self.customers = {}
    
    # creating data 
    def add_room(self, room):
        self.rooms[room.room_number] = room
    
    def add_reservation(self, reservation):
        self.reservations.append(reservation)
    
    def add_customer(self, customer):
        self.customers[customer.customer_id] = customer
    
    # view data
    def get_rooms(self):
        return self.rooms
    
    def get_reservations(self):
        return self.reservations
    
    def get_customers(self):
        return self.customers
   
    # search data
    def find_room_by_number(self, room_number):
        return self.rooms.get(room_number)
    
    def find_available_rooms(self, style, start_date, duration):
        available_rooms = []
        for room in self.get_rooms().values():
            if room.search(style, start_date, duration):
                available_rooms.append(room)
        return available_rooms
    
    def find_customer_by_id(self, customer_id):
        return self.customers.get(customer_id)
   