from datetime import datetime
import json
import os

from models.customer import Customer
from models.reservation import Reservation
from models.room import Room
from utilities.database import Database
from utilities.promotion import PromotionCodeDiscount

def main():
    db = Database()
    
    current_dir = os.path.dirname(os.path.abspath(__file__))
    rooms_json_file_path = os.path.join(current_dir, '..', 'rooms.json')
    
    def load_rooms_from_json(file_path):
        with open(file_path, 'r') as file:
            rooms_data = json.load(file)
            for room_data in rooms_data:
                room = Room(
                    room_number=room_data['num'],
                    room_style=room_data['type'],
                    status=room_data['status'],
                    price=room_data['price']
                )
                db.add_room(room)
    load_rooms_from_json(rooms_json_file_path)
    
    # 고객 생성
    customer1 = Customer(customer_id=1, name="Alice", contact_info="alice@example.com", birth_year=1995)
    db.add_customer(customer1)
    
    # 예약 생성
    start_date = datetime(2023, 6, 15)
    reservation1 = Reservation(
        reservation_number=101,
        start_date=start_date,
        duration_in_days=3,
        room_style='suite',
        booking_status='requested',
        customer=customer1
    )
    db.add_reservation(reservation1)
    
    # 호텔 매니저가 방을 할당
    available_rooms = db.find_available_rooms('suite', start_date, 3)
    if available_rooms:
        room_to_assign = available_rooms[0] # 편의상 가능한 객실 리스트 중 가장 처음 객실을 assign
        reservation1.assign_room(db, room_to_assign.room_number)
        print(f"Room {room_to_assign.room_number} assigned to reservation {reservation1.reservation_number}.")
    else:
        print("No available rooms found.")
    
    print(reservation1.status)
    print(room_to_assign.status)
    
    # 체크인 처리
    checkin_time = datetime(2023, 6, 15, 14, 0)  # 오후 2시 체크인
    room_to_assign.check_in(reservation1, checkin_time)
    print(f"Customer {reservation1.customer.name} checked in on {reservation1.checkin}.")
    
    print(reservation1.status)
    print(room_to_assign.status)
    print(reservation1.checkin)
    reservation1.create_checkin_invoice()
    print(reservation1.checkin_invoice)
    
    # 고객의 추가비용 처리
    reservation1.add_notification('Roomservice', 50000)
    reservation1.add_notification('selfbar', 30000)
    print(reservation1.notifications)
    
    # 고객 comment 관리
    customer1.add_comment('Prefers medium rare steak')
    print(customer1.fetch_comments())
    
    # 프로모션 코드 적용
    promotion_code = PromotionCodeDiscount(code="FREESELFBARSUITE")
    promotion_code.apply(reservation1)
    print("Applied Promotions:")
    for detail in reservation1.promotion_details:
        print(detail)

    # 체크아웃 처리
    checkout_time = datetime(2023, 6, 18, 9, 0)  # 오전 9시 체크아웃
    room_to_assign.check_out(reservation1, checkout_time)
    print(f"Customer {reservation1.customer.name} checked out on {reservation1.checkout}.")

    print(reservation1.status)
    print(room_to_assign.status)
    print(reservation1.checkout)
    reservation1.create_checkout_invoice()
    print(reservation1.checkout_invoice)

        
if __name__ == "__main__":
    main()