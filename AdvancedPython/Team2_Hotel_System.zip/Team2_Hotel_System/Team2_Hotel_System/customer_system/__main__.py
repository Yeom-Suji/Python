from datetime import datetime
import json
import os
os.environ["PYTHONIOENCODING"] = "utf-8"


from models.customer import Customer
from models.reservation import Reservation
from models.room import Room
from utilities.database import Database


############################################################

db = Database()

def load_rooms_from_json(file_path):
    with open(file_path, 'r') as file:
        rooms_data = json.load(file)
        for room_data in rooms_data:
            room = Room(
                room_number=room_data['num'],
                room_style=room_data['type'],
                status=room_data['status'],
                price=room_data['price']
            )
            db.add_room(room)

current_dir = os.path.dirname(os.path.abspath(__file__))
rooms_json_file_path = os.path.join(current_dir, '..', 'rooms.json')
load_rooms_from_json(rooms_json_file_path)

# customer도 불러오기
def load_customers_from_json(file_path):
    with open(file_path, 'r') as file:
        customers_data = json.load(file)
        for customer_id, customer_data in customers_data.items():
            customer = Customer(
                customer_id=customer_data['customer_id'],
                name=customer_data['name'],
                contact_info=customer_data['contact_info'],
                birth_year=customer_data['birth_year']
            )
            customer.membership_tier = customer_data.get('membership_tier', 'bronze')
            customer.points = customer_data.get('points', 0)
            customer.stay_count = customer_data.get('stay_count', 0)
            customer.comments = customer_data.get('comments', [])
            db.add_customer(customer)

customers_json_file_path = os.path.join(current_dir, '..', 'users.json')
load_customers_from_json(customers_json_file_path)

def load_reservations_from_json(file_path):
    with open(file_path, 'r') as file:
        reservations_data = json.load(file)
        for reservation_data in reservations_data:
            customer = db.customers.get(reservation_data['customer'])
            if customer:
                reservation = Reservation(
                    reservation_number=reservation_data['reservation_number'],
                    start_date=datetime.fromisoformat(reservation_data['start_date']),
                    duration_in_days=reservation_data['duration_in_days'],
                    room_style=reservation_data['room_style'],
                    booking_status=reservation_data['status'],
                    customer=customer
                )
                reservation.checkin = datetime.fromisoformat(reservation_data['checkin']) if reservation_data['checkin'] else None
                reservation.checkout = datetime.fromisoformat(reservation_data['checkout']) if reservation_data['checkout'] else None
                reservation.total_amount = reservation_data['total_amount'] if reservation_data['total_amount'] else 0
                reservation.promotion_details = reservation_data['promotion_details']
                reservation.notifications = reservation_data['notifications']
                
                if 'room' in reservation_data and reservation_data['room']:
                    room = db.rooms.get(reservation_data['room'])
                    reservation.room = room
                    
                db.add_reservation(reservation)

reservations_json_file_path = os.path.join(current_dir, '..', 'reservations.json')
load_reservations_from_json(reservations_json_file_path)

# Customer searches available room
start_date = datetime(2024, 6, 20)
duration = 3
people_count = 2
promo_code = 'STANDARDFREE'

available_rooms = db.get_available_rooms(start_date, duration, people_count, promo_code)
print(available_rooms)

# Customer finds out that avilable room type for
# Two people for 3 days starting 2024.6.20 using promotion code is 'standard'

# Customer makes a reservation
customer = db.customers.get(1)
reservation = Reservation(4, datetime(2024, 6, 13), 2, 'standard', 'requested', customer)
db.add_reservation(reservation)

# customer has to wait until the room is assigned

# 예약 정보 출력 함수
def print_reservation_info(reservations):
    for res in reservations:
        print(f"Reservation Number: {res.reservation_number}")
        print(f"Start Date: {res.start_date}")
        print(f"Duration: {res.duration_in_days} days")
        print(f"Room Style: {res.room_style}")
        print(f"Status: {res.status}")
        print(f"Check-in: {res.checkin}")
        print(f"Check-out: {res.checkout}")
        print(f"Customer: {res.customer.name}")
        print(f"Total Amount: {res.total_amount}")
        print(f"Promotion Details: {res.promotion_details}")
        print(f"Room: {res.room}")
        print(f"Notifications: {res.notifications}")
        print("-" * 40)


# Customer view her stays
customer_id = 1
upcoming_stays = db.get_customer_reservations(customer_id, stay_type='upcoming')
past_stays = db.get_customer_reservations(customer_id, stay_type='past')
canceled_stays = db.get_customer_reservations(customer_id, stay_type='canceled')

print("Upcoming Stays:")
print_reservation_info(upcoming_stays)

print("\nPast Stays:")
print_reservation_info(past_stays)

print("\nCanceled Stays:")
print_reservation_info(canceled_stays)

# She has two upcoming stays, and reservation number 3 has assigned room.
# She will try self check in

reservation_number = 3
reservation = db.get_reservation_by_number(reservation_number)

# 셀프 체크인 시도
arrival_time = "14:00"
mobile_key = "ABC123"
billing_info = {"card_number": "1234-5678-9012-3456", "expiry": "12/24"}

if reservation.self_check_in(arrival_time, mobile_key, billing_info):
    print(f"Reservation {reservation_number} successfully checked in.")
else:
    print(f"Reservation {reservation_number} is not eligible for self check-in.")

# 최종 예약 상태 출력
print("\nFinal Reservation Status:")
print_reservation_info([reservation])

# My account
print(db.get_customer_account_info(1))