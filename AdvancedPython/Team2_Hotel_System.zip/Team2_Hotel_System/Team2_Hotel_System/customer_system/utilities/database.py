class Database:
    def __init__(self):
        self.rooms = {}
        self.reservations = []
        self.customers = {}
        
    def add_room(self, room):
        self.rooms[room.room_number] = room
        
    def add_reservation(self, reservation):
        self.reservations.append(reservation)
        
    def add_customer(self, customer):
        self.customers[customer.customer_id] = customer
        
    def get_customer_reservations(self, customer_id, stay_type=None):
        customer_reservations = [res for res in self.reservations if res.customer.customer_id == customer_id]
        if stay_type:
            if stay_type == 'upcoming':
                customer_reservations = [res for res in customer_reservations if res.status in ['requested','confirmed', 'checked_in']]
            elif stay_type == 'past':
                customer_reservations = [res for res in customer_reservations if res.status == 'checked_out']
            elif stay_type == 'canceled':
                customer_reservations = [res for res in customer_reservations if res.status == 'canceled']
        return customer_reservations
    
    def get_available_rooms(self, start_date, duration, people_count, promo_code=None):
        available_rooms = []
        promo_code_rooms = {
            'STANDARDFREE': ['standard'],
            'FREESELFBARSUITE': ['suite', 'family_suite']
        }

        for room in self.rooms.values():
            if promo_code:
                if room.style not in promo_code_rooms.get(promo_code, []):
                    continue

            if room.search(room.style, start_date, duration, people_count):
                if (room.style, room.booking_price) not in available_rooms:
                    available_rooms.append((room.style, room.booking_price))

        return available_rooms
    
    def get_reservation_by_number(self, reservation_number):
        for reservation in self.reservations:
            if reservation.reservation_number == reservation_number:
                return reservation
        return None
    
    def get_customer_account_info(self, customer_id):
        customer = self.customers.get(customer_id)
        if customer:
            return {
                "Name": customer.name,
                "Membership number": customer.customer_id,
                "Tier": customer.membership_tier,
                "Nights this year": customer.stay_count,
                "Points": customer.points
            }
        return None
