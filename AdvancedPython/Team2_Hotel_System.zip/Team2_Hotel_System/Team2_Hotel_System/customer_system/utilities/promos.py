from datetime import datetime
from abc import ABC, abstractmethod

class Promotion(ABC):
    @abstractmethod
    def apply(self, reservation):
        pass

class MembershipDiscount(Promotion):
    
    TIER_DISCOUNTS = {
        'bronze': 0,
        'silver': 0.01,
        'gold': 0.03,
        'platinum': 0.05,
        'diamond': 0.08
    }

    def apply(self, reservation):
        tier = reservation.customer.membership_tier
        discount = self.TIER_DISCOUNTS.get(tier, 0)
        discount_amount = reservation.total_amount * discount
        reservation.total_amount -= discount_amount
        reservation.promotion_details.append(f"Membership discount ({tier}): -{discount_amount:.2f}")

class StayCountDiscount(Promotion):
    def apply(self, reservation):
        if reservation.customer.stay_count >= 5:
            discount_amount = reservation.total_amount * 0.05
            reservation.total_amount -= discount_amount
            reservation.promotion_details.append(f"Stay count discount (5+ stays): -{discount_amount:.2f}")

class AgeDiscount(Promotion):
    def apply(self, reservation):
        birth_year = reservation.customer.birth_year
        current_year = datetime.now().year
        age = current_year - birth_year
        if age == 20:
            discount_amount = 50000
            reservation.total_amount -= discount_amount
            reservation.promotion_details.append(f"Age discount (20 years old): -{discount_amount:.2f}")

class PromotionCodeDiscount(Promotion):
    def __init__(self, code):
        self.code = code
        
    def apply(self, reservation):
        if self.code == "STANDARDFREE" and reservation.room_style == "standard":
            reservation.total_amount = 0
            reservation.promotion_details.append("Promotion code (STANDARDFREE): Room cost waived")
        elif self.code == "FREESELFBARSUITE" and reservation.room_style in ["suite", "family_suite"]:
            for notification in reservation.notifications:
                if "selfbar" in notification['description'].lower():
                    reservation.total_amount -= notification['cost']
                    reservation.promotion_details.append(f"Promotion code (FREESELFBARSUITE): Selfbar cost waived -{notification['cost']}")
