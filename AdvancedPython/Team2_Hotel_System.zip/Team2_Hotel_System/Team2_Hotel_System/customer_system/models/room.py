from datetime import timedelta, time
from abc import ABC, abstractmethod

class Search(ABC):
    @abstractmethod
    def search(self, style, start_date, duration):
        pass
            
class Room(Search):
    
    CHECK_IN_TIME = time(13, 0)  # 13:00
    CHECK_OUT_TIME = time(10, 0)  # 10:00
    
    ROOM_CAPACITIES = {
        'standard': 2,
        'executive': 3,
        'deluxe': 4,
        'suite': 6,
        'family_suite': 6
    }
    
    def __init__(self, room_number, room_style, status, price):
        self.room_number = room_number
        self.style = room_style # standard, executive, deluxe, suite, family_suite
        self.status = status # ready, reserved, occupied, house_keeping
        self.booking_price = price # differenciated by room_style
        self.max_capacity = self.ROOM_CAPACITIES.get(room_style, 2)

        self.reservations = []
    def is_room_available(self, start_date, duration):
        end_date = start_date + timedelta(days=duration) 
        for reservation in self.reservations: # 객실의 예약을 확인
            res_start = reservation.start_date 
            res_end = res_start + timedelta(days=reservation.duration_in_days)
            if (start_date < res_end and end_date > res_start):  
                return False
        return True
        
    def __str__(self):
        return f"Room {self.room_number}"
        
    def search(self, style, start_date, duration, people_count):
        return self.style == style and self.is_room_available(start_date, duration) and self.max_capacity >= people_count
