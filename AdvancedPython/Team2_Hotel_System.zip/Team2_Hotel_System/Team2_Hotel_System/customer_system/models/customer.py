class Customer:
    
    def __init__(self, customer_id, name, contact_info, birth_year):
        self.customer_id = customer_id
        self.name = name
        self.contact_info = contact_info
        self.birth_year = birth_year
        self.membership_tier = 'bronze'
        self.points = 0
        self.stay_count = 0  # 고객의 올해 숙박 횟수를 저장
        self.comments = []
