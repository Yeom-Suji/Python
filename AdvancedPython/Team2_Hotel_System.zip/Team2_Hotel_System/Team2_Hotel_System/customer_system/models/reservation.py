from datetime import datetime, timedelta

class Reservation:
    def __init__(self, reservation_number, start_date, duration_in_days, room_style, booking_status, customer):
        self.reservation_number = reservation_number
        self.start_date = start_date
        self.duration_in_days = duration_in_days
        self.room_style = room_style
        self.status = booking_status # requested, confirmed, checked_in, checked_out, canceled
        self.checkin = None
        self.checkout = None
        self.customer = customer
        self.total_amount = 0
        self.promotion_details = []  # 프로모션 적용 세부사항
        
        self.room = None
        self.checkin_invoice = None
        self.checkout_invoice = None
        self.notifications = []
        
        self.arrival_time = None
        self.mobile_key = None
        self.billing_info = None
        
    def is_eligible_for_check_in(self):
        now = datetime.now()
        check_in_start = self.start_date - timedelta(days=1)
        return now >= check_in_start and self.status in ['requested', 'confirmed']

    def self_check_in(self, arrival_time, mobile_key, billing_info):
        if self.is_eligible_for_check_in():
            self.checkin = datetime.now()
            self.arrival_time = arrival_time
            self.mobile_key = mobile_key
            self.billing_info = billing_info
            self.status = 'checked_in'
            return True
        return False
